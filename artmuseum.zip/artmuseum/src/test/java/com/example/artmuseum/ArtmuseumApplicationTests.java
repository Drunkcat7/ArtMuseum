package com.example.artmuseum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtmuseumApplicationTests {

	@Test
	void contextLoads() {
	}

}
